import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Translations for multiple languages
// Common translation keys used across the app
const translations = {
  common: {
    login: 'Login',
    register: 'Register',
    logout: 'Logout',
    username: 'Username',
    password: 'Password',
    adminUsername: 'Admin Username',
    adminPassword: 'Admin Password',
    email: 'Email',
    fullName: 'Full Name',
    dashboard: 'Dashboard',
    profile: 'Profile',
    admin: 'Admin',
    restaurantOwner: 'Restaurant Owner',
    adminLogin: 'Admin Login',
    adminOnly: 'For platform administrators only',
    noAccount: 'Don\'t have an account?',
    createAccount: 'Create Account',
    successLogin: 'You have been logged in successfully',
    successAdminLogin: 'Admin login successful',
    invalidCredentials: 'Invalid username or password',
    invalidAdminCredentials: 'Invalid admin credentials',
    language: 'Language',
    translateMenu: 'Translate Menu',
  },
  home: {
    welcome: 'Welcome to MenuMate',
    subtitle: 'Create and share digital menus for your restaurant',
    getStarted: 'Get Started',
    learnMore: 'Learn More',
  },
  dashboard: {
    myRestaurants: 'My Restaurants',
    createRestaurant: 'Create Restaurant',
    subscriptionStatus: 'Subscription Status',
    stats: 'Statistics',
    viewMenu: 'View Menu',
    editMenu: 'Edit Menu',
    shareMenu: 'Share Menu',
    upgradeAccount: 'Upgrade Account',
    freeAccount: 'Free Account',
    premiumAccount: 'Premium Account',
    restaurantLimit: 'Restaurant limit:',
    expirationDate: 'Expiration date:',
  },
  menu: {
    categories: 'Categories',
    items: 'Items',
    price: 'Price',
    description: 'Description',
    addCategory: 'Add Category',
    addItem: 'Add Item',
    editCategory: 'Edit Category',
    editItem: 'Edit Item',
    deleteCategory: 'Delete Category',
    deleteItem: 'Delete Item',
    confirmDelete: 'Are you sure you want to delete this?',
    availableItems: 'Available Items',
    tags: 'Tags',
    uploadImage: 'Upload Image',
    imageSize: 'Max image size: 3MB',
    all: 'All',
    food: 'Food',
    beverage: 'Beverage',
    clickToLeaveFeedback: 'Click to leave feedback',
    noImage: 'No image',
    noItemsInCategory: 'No items in this category',
    noMenuItems: 'No menu items yet',
    previewMode: 'Preview Mode',
  },
  restaurant: {
    uploadLogo: 'Upload Restaurant Logo',
    logoSize: 'Max logo size: 3MB',
    uploadBanner: 'Upload Restaurant Banner',
    bannerSize: 'Max banner size: 3MB',
    feedback: 'Customer Feedback',
    viewFeedback: 'View Feedback',
    noFeedback: 'No feedback yet',
    leaveFeedback: 'Share Your Experience',
  },
  subscription: {
    choosePlan: 'Choose Your Plan',
    freePlan: 'Free Plan',
    premiumPlan: 'Premium Plan',
    monthlyBilling: 'Monthly Billing',
    yearlyBilling: 'Yearly Billing',
    subscribe: 'Subscribe',
    features: 'Features',
    includedFeatures: 'Included Features',
    restaurantLimit: 'Restaurant Limit',
    adsDisplay: 'Ads Display',
    support: 'Support',
    yes: 'Yes',
    no: 'No',
    basic: 'Basic',
    priority: 'Priority',
  },
  feedback: {
    leaveFeedback: 'Leave Feedback',
    yourRating: 'Your Rating',
    yourComment: 'Your Comment',
    name: 'Name',
    email: 'Email',
    submit: 'Submit Feedback',
    thankYou: 'Thank you for your feedback!',
  },
  admin: {
    adminPanel: 'Admin Panel',
    restaurants: 'Restaurants',
    users: 'Users',
    subscriptions: 'Subscriptions',
    feedback: 'Feedback',
    overview: 'Overview',
    premiumUsers: 'Premium Users',
    totalRestaurants: 'Total Restaurants',
    totalFeedback: 'Total Feedback',
    recentSubscriptions: 'Recent Subscriptions',
    allRestaurants: 'All Restaurants',
    allSubscriptions: 'All Subscriptions',
    allFeedback: 'All Feedback',
    approveFeedback: 'Approve',
    rejectFeedback: 'Reject',
  },
};

// Additional languages
const amharicTranslations = {
  common: {
    login: 'ግባ',
    register: 'ተመዝገብ',
    logout: 'ውጣ',
    username: 'የተጠቃሚ ስም',
    password: 'የይለፍ ቃል',
    language: 'ቋንቋ',
    translateMenu: 'ምናሌዉን ተረጉም',
  },
  menu: {
    categories: 'ምድቦች',
    items: 'ምግቦች',
    price: 'ዋጋ',
    description: 'መግለጫ',
    all: 'ሁሉም',
    food: 'ምግብ',
    beverage: 'መጠጥ',
    clickToLeaveFeedback: 'አስተያየት ለመስጠት ይጫኑ',
    noImage: 'ምስል የለም',
    noItemsInCategory: 'በዚህ ምድብ ውስጥ ምንም ምግቦች የሉም',
    noMenuItems: 'እስካሁን ምንም ምግቦች አልተጨመሩም',
    previewMode: 'የናሙና ሁኔታ',
    tags: 'መለያዎች'
  },
  restaurant: {
    feedback: 'የደንበኛ አስተያየት',
    leaveFeedback: 'አስተያየትዎን ያጋሩ',
  }
};

const frenchTranslations = {
  common: {
    login: 'Connexion',
    register: 'S\'inscrire',
    logout: 'Déconnexion',
    username: 'Nom d\'utilisateur',
    password: 'Mot de passe',
    language: 'Langue',
    translateMenu: 'Traduire le menu',
  },
  menu: {
    categories: 'Catégories',
    items: 'Articles',
    price: 'Prix',
    description: 'Description',
    all: 'Tous',
    food: 'Nourriture',
    beverage: 'Boisson',
    clickToLeaveFeedback: 'Cliquez pour laisser un commentaire',
    noImage: 'Pas d\'image',
    noItemsInCategory: 'Aucun article dans cette catégorie',
    noMenuItems: 'Pas encore d\'articles de menu',
    previewMode: 'Mode Aperçu',
    tags: 'Étiquettes'
  },
  restaurant: {
    feedback: 'Commentaires des clients',
    leaveFeedback: 'Partagez votre expérience',
  }
};

const arabicTranslations = {
  common: {
    login: 'تسجيل الدخول',
    register: 'التسجيل',
    logout: 'تسجيل الخروج',
    username: 'اسم المستخدم',
    password: 'كلمة المرور',
    language: 'اللغة',
    translateMenu: 'ترجمة القائمة',
  },
  menu: {
    categories: 'الفئات',
    items: 'العناصر',
    price: 'السعر',
    description: 'الوصف',
    all: 'الكل',
    food: 'طعام',
    beverage: 'مشروبات',
    clickToLeaveFeedback: 'انقر لترك تعليق',
    noImage: 'لا توجد صورة',
    noItemsInCategory: 'لا توجد عناصر في هذه الفئة',
    noMenuItems: 'لا توجد عناصر في القائمة حتى الآن',
    previewMode: 'وضع المعاينة',
    tags: 'العلامات'
  },
  restaurant: {
    feedback: 'آراء العملاء',
    leaveFeedback: 'شارك تجربتك',
  }
};

// Chinese translations
const chineseTranslations = {
  common: {
    login: '登录',
    register: '注册',
    logout: '退出登录',
    username: '用户名',
    password: '密码',
    adminUsername: '管理员用户名',
    adminPassword: '管理员密码',
    email: '电子邮件',
    fullName: '全名',
    dashboard: '仪表板',
    profile: '个人资料',
    admin: '管理员',
    restaurantOwner: '餐厅老板',
    adminLogin: '管理员登录',
    adminOnly: '仅限平台管理员',
    noAccount: '没有账号？',
    createAccount: '创建账号',
    successLogin: '登录成功',
    successAdminLogin: '管理员登录成功',
    invalidCredentials: '用户名或密码无效',
    invalidAdminCredentials: '管理员凭据无效',
    language: '语言',
    translateMenu: '翻译菜单',
  },
  home: {
    welcome: '欢迎使用 VividPlate',
    subtitle: '为您的餐厅创建和分享数字菜单',
    getStarted: '开始使用',
    learnMore: '了解更多',
  },
  dashboard: {
    myRestaurants: '我的餐厅',
    createRestaurant: '创建餐厅',
    subscriptionStatus: '订阅状态',
    stats: '统计数据',
    viewMenu: '查看菜单',
    editMenu: '编辑菜单',
    shareMenu: '分享菜单',
    upgradeAccount: '升级账户',
    freeAccount: '免费账户',
    premiumAccount: '高级账户',
    restaurantLimit: '餐厅限制：',
    expirationDate: '到期日期：',
  },
  menu: {
    categories: '分类',
    items: '菜品',
    price: '价格',
    description: '描述',
    addCategory: '添加分类',
    addItem: '添加菜品',
    editCategory: '编辑分类',
    editItem: '编辑菜品',
    deleteCategory: '删除分类',
    deleteItem: '删除菜品',
    confirmDelete: '确定要删除吗？',
    availableItems: '可用菜品',
    tags: '标签',
    uploadImage: '上传图片',
    imageSize: '最大图片大小: 3MB',
    all: '全部',
    food: '食物',
    beverage: '饮料',
    clickToLeaveFeedback: '点击留下反馈',
    noImage: '无图片',
    noItemsInCategory: '该分类下没有菜品',
    noMenuItems: '暂无菜品',
    previewMode: '预览模式',
  },
  restaurant: {
    uploadLogo: '上传餐厅标志',
    logoSize: '最大标志大小: 3MB',
    uploadBanner: '上传餐厅横幅',
    bannerSize: '最大横幅大小: 3MB',
    feedback: '顾客反馈',
    viewFeedback: '查看反馈',
    noFeedback: '暂无反馈',
    leaveFeedback: '分享您的体验',
  },
  subscription: {
    choosePlan: '选择您的计划',
    freePlan: '免费计划',
    premiumPlan: '高级计划',
    monthlyBilling: '月付',
    yearlyBilling: '年付',
    subscribe: '订阅',
    features: '功能',
    includedFeatures: '包含功能',
    restaurantLimit: '餐厅限制',
    adsDisplay: '广告显示',
    support: '支持',
    yes: '是',
    no: '否',
    basic: '基础',
    priority: '优先',
  },
  feedback: {
    leaveFeedback: '留下反馈',
    yourRating: '您的评分',
    yourComment: '您的评论',
    name: '姓名',
    email: '电子邮件',
    submit: '提交反馈',
    thankYou: '感谢您的反馈！',
  },
  admin: {
    adminPanel: '管理员面板',
    restaurants: '餐厅',
    users: '用户',
    subscriptions: '订阅',
    feedback: '反馈',
    overview: '概览',
    premiumUsers: '高级用户',
    totalRestaurants: '餐厅总数',
    totalFeedback: '反馈总数',
    recentSubscriptions: '最近订阅',
    allRestaurants: '所有餐厅',
    allSubscriptions: '所有订阅',
    allFeedback: '所有反馈',
    approveFeedback: '批准',
    rejectFeedback: '拒绝',
  },
};

// Initialize i18next
i18n
  .use(initReactI18next)
  .use(LanguageDetector)
  .init({
    resources: {
      en: {
        translation: translations
      },
      am: {
        translation: amharicTranslations
      },
      fr: {
        translation: frenchTranslations
      },
      ar: {
        translation: arabicTranslations
      },
      zh: {
        translation: chineseTranslations
      }
    },
    lng: 'en',
    fallbackLng: 'en',
    debug: process.env.NODE_ENV === 'development',
    interpolation: {
      escapeValue: false, // not needed for react as it escapes by default
    },
    detection: {
      order: ['querystring', 'localStorage', 'navigator'],
      lookupQuerystring: 'lang',
      lookupLocalStorage: 'i18nextLng',
      caches: ['localStorage'],
    }
  });

export default i18n;